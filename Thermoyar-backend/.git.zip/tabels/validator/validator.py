def anyInputIsEmpty(*values):
    for value in values:
        if len(value.strip()) is 0 or value == 'what':
            return True
            break
    return False

def inputHasLetter(value):
    if not anyInputIsEmpty(value):
        if value.isdecimal():
            return False
        return True
    return False
