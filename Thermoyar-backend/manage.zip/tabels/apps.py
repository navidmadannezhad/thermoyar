from django.apps import AppConfig


class TabelsConfig(AppConfig):
    name = 'tabels'
